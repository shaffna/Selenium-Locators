package SeleniumLocators.SeleniumLocators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class firefoxbrowser {
	
	static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		
		 WebDriverManager.firefoxdriver().setup();

	        WebDriver driver = new FirefoxDriver();
            driver.manage().window().maximize();
            driver.get("http://google.com");
	        String currentUrl = driver.getCurrentUrl();
	        System.out.println("Current URL:"    +currentUrl);
	        driver.navigate().refresh();
            Thread.sleep(5000);
            driver.close();
	}

}
