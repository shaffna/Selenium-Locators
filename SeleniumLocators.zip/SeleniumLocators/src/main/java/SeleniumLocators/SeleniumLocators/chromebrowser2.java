package SeleniumLocators.SeleniumLocators;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class chromebrowser2 {
	static WebDriver driver;
	public static void main(String[] args) {
	
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		 driver.manage().window().maximize();
		driver.get("https://www.wikipedia.org/");
		WebElement myElement =  driver.findElement(By.id("searchInput"));
		myElement.sendKeys("Artificial Intelligence");
		myElement.submit();
		
		WebElement myElement1 = driver.findElement(By.partialLinkText("History"));
		myElement1.click();
		 String sectionTitle = driver.getTitle();
         System.out.println("Title of the section: " + sectionTitle);
	}

}
